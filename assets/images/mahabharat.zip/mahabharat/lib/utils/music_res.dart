class MusicRes {
  static const titleSong = "assets/music/mahabharat_song.mp3";
}
