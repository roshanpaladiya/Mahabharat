import 'package:flutter/material.dart';

class ColorRes {
  static const redColor = Colors.red;
  static const greenColor = Colors.green;
  static const orangeAssentColor = Colors.orangeAccent;
  static const orangeColor = Colors.orange;
  static const yellowColor = Colors.yellow;
  static const blackColor = Colors.black;
  static const black87Color = Colors.black87;
  static const whiteColor = Colors.white;
  static const transparentColor = Colors.transparent;
  static const black54Color = Colors.black54;
  static const greyColor = Colors.grey;
  static const white70Color = Colors.white70;
}
