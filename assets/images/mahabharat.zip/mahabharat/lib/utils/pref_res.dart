class PrefRes {
  static const bookString = "bookString";
}
