class EndPointRes {
  static const apiUrl = "https://mahabharat.nopcypher.com/api/client/GetProductsByCategoryId/362";
}
