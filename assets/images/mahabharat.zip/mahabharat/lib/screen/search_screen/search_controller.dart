import 'package:flutter/material.dart';
import 'package:get/get.dart';

class SearchPageController extends GetxController {
  String value = "";
  TextEditingController searchText = TextEditingController();
}
